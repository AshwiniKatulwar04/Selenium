package com.login;



import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import dev.failsafe.internal.util.Assert;

public class LoginPageConfiguration {

	public static void main(String[] args) {
		LoginPageConfiguration obj = new LoginPageConfiguration();
		obj.login();
		}
	
    @Test
    public void login() {
	System.setProperty("webdriver.chrome.driver", "E:\\chromeDriver");
    ChromeDriver driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.manage().deleteAllCookies();
    driver.manage().timeouts().pageLoadTimeout(15,TimeUnit.SECONDS);
    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    driver.get("https://www.saucedemo.com/");
    String arr[][]= { {"standard_user","secret_sauce"} , {"locked_out_user","secret_sauce"} , {"problem_user","secret_sauce"} , {"performance_glitch_user","secret_sauce"} };
      for(int i=0; i<arr.length-1 ; i++){
    	for(int j=0;j<arr.length;j++) {
           WebElement username=driver.findElement(By.id("//input[@id='user-name']"));
           WebElement password=driver.findElement(By.id("//input[@id='password']"));
           WebElement login=driver.findElement(By.id("//input[@id='login-button']"));
           username.sendKeys(arr[i][j]);
           password.sendKeys(arr[i+1][j]);
           login.click();
           String actualUrl="\"https://www.saucedemo.com/inventory.html";
           String expectedUrl= driver.getCurrentUrl();
        	 Assert.assertEquals(expectedUrl,actualUrl);
	       }
         }
       }
}

